package com.cts.student.service.exception;

/**
 * 
 * @author 882851
 *
 */
@SuppressWarnings("serial")
public class StudentNotFoundException extends Exception {
	
	public StudentNotFoundException()
	{
		
	}
	public StudentNotFoundException(String message)
	{
		super(message);
	}
	
	

}
